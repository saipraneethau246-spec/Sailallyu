import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(page_title="Smart Agriculture Dashboard", page_icon="🌾", layout="wide")
st.title("🌾 Smart Agriculture Dashboard")
st.write("Agriculture Data Visualization using Streamlit")
st.caption("Demo dataset only — these values are illustrative, not verified agricultural statistics.")

df = pd.read_csv("agriculture.csv")

st.sidebar.header("🔍 Filters")
states = st.sidebar.multiselect("Select State", sorted(df["State"].unique()), default=sorted(df["State"].unique()))
crops = st.sidebar.multiselect("Select Crop", sorted(df["Crop"].unique()), default=sorted(df["Crop"].unique()))
seasons = st.sidebar.multiselect("Select Season", sorted(df["Season"].unique()), default=sorted(df["Season"].unique()))

filtered_df = df[
    df["State"].isin(states) &
    df["Crop"].isin(crops) &
    df["Season"].isin(seasons)
]

if filtered_df.empty:
    st.warning("No records match these filters. Please select at least one state, crop, and season.")
    st.stop()

col1, col2, col3, col4 = st.columns(4)
col1.metric("🌱 Total Area", f"{filtered_df['Area_Hectares'].sum():,.0f} ha")
col2.metric("🌾 Production", f"{filtered_df['Production_Tonnes'].sum():,.0f} tonnes")
col3.metric("📈 Average Yield", f"{filtered_df['Yield_Tonnes_Ha'].mean():.2f} tonnes/ha")
col4.metric("🌧 Average Rainfall", f"{filtered_df['Rainfall_mm'].mean():.0f} mm")
st.divider()

left, right = st.columns(2)
with left:
    st.subheader("🌾 Production by Crop")
    crop_data = filtered_df.groupby("Crop", as_index=False)["Production_Tonnes"].sum()
    fig1 = px.bar(crop_data, x="Crop", y="Production_Tonnes", title="Production by Crop")
    st.plotly_chart(fig1, use_container_width=True)
with right:
    st.subheader("🌧 Rainfall vs Yield")
    fig2 = px.scatter(
        filtered_df, x="Rainfall_mm", y="Yield_Tonnes_Ha", color="Crop",
        hover_data=["State", "District"], title="Rainfall vs Crop Yield"
    )
    st.plotly_chart(fig2, use_container_width=True)

left, right = st.columns(2)
with left:
    st.subheader("🌱 Production by Soil Type")
    soil_data = filtered_df.groupby("Soil_Type", as_index=False)["Production_Tonnes"].sum()
    fig3 = px.pie(soil_data, names="Soil_Type", values="Production_Tonnes",
                  title="Production Distribution by Soil Type")
    st.plotly_chart(fig3, use_container_width=True)
with right:
    st.subheader("📈 Production by Year")
    year_data = filtered_df.groupby("Year", as_index=False)["Production_Tonnes"].sum()
    fig4 = px.line(year_data, x="Year", y="Production_Tonnes", markers=True,
                   title="Production Over Time")
    st.plotly_chart(fig4, use_container_width=True)

st.subheader("📋 Agriculture Dataset")
st.dataframe(filtered_df, use_container_width=True)
st.download_button(
    "⬇️ Download Data",
    data=filtered_df.to_csv(index=False).encode("utf-8"),
    file_name="agriculture_data.csv",
    mime="text/csv",
)
