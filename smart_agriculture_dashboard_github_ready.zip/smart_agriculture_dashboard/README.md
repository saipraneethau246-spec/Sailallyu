# Smart Agriculture Dashboard 🌾

A Streamlit dashboard for agricultural data visualization using Pandas and Plotly.

## Features
- Filters by state, crop, and season
- Summary metrics for area, production, average yield, and rainfall
- Bar chart: production by crop
- Scatter plot: rainfall vs yield
- Pie chart: production by soil type
- Line chart: production by year
- Dataset table and CSV download

## Run locally
1. Install Python.
2. Open a terminal in this folder.
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Start the dashboard:
   ```bash
   streamlit run app.py
   ```

## Dataset note
`agriculture.csv` contains illustrative demonstration values only. They are not verified agricultural statistics. Replace them with a trusted dataset before using the dashboard for real-world conclusions.
